/**
 * 根据经纬度获取所在的城市
 * @param (Function)  cb      获取城市调用的回调函数
 */
function getCity(cb){
  wx.getLocation({
    success: function (res) {
      let longitude = res.longitude;
      let latitude = res.latitude;

      // 根据地理位置获取所在城市
      let url = 'https://api.map.baidu.com/geocoder/v2/?ak=2IBKO6GVxbYZvaR2mf0GWgZE&output=json&pois=0"&location=' + latitude + ',' + longitude;
      get(url, function (obj) {
        let city = obj.data.result.addressComponent.city;
        city = city.replace('市', '');
        cb(city);
      });
    }
  });
}
/**
 * 使用get方式请求网络数据
 * @param (String)  url     获取数据的网址
 * @param (Function)        获取数据后的回调函数
 */
function get(url, cb){
  wx.request({
    url: url,
    method: 'get',
    dataType: 'json',
    header: {
      'Content-Type': 'json'
    },
    success: function (obj) {
      cb(obj);
    }
  })
}

/**
 * 把分数转换为星号
 * @param (Double) score    分数
 * @return (Array)  
 */
function convertScore(score){
  let arr = [];
  let half = Math.round(score / 2);
  for (let i=0;i<5;i++){
    // 分数的一半大于i就显示有颜色的星号(true)，否则是灰色的星号(false)
    let bool = half > i;
    arr.push(bool);
  }
  return arr;
}
/**
 * 转换字符串到指定的长度
 * @param (String) title      需要转换的字符串
 * @param (Integer) len       需要的长度
 * @return (String)
 */
function convertTitle(title, len){
  if (title.length > len){
    return title.substring(0, len) + "…";
  }
  return title;
}

/**
 * 把得到的电影数据转换为json对象
 * @param(JSON) obj       一部电影的数据
 * @param(Integer) len    标签的长度限制，默认是5个字符
 */
function convertData(obj, len=5){
  let t = obj;
  let title = convertTitle(t.title, len);
  let imageUrl = t.images.small;
  let score = t.rating.average;
  let id = t.id

  let stars = convertScore(score);
  return{
    coverageUrl: imageUrl,
    movieTitle: title,
    stars: stars,
    starScore: '' + score,
    id: id
  };
}
/**
 * 解释所有的电影数据
 * @param(String) url         获取数据的地址
 * @param(String) title       电影的分类类别类
 * @param(JSON) data          数据的模型
 * @param(String) key         保存在json对象中的key
 */
//function parseData(url, title, data, key, cb){
function parseData(url, cb) {
  getCity(function (city) {
    get(url+'&city='+city, function (obj) {
      let subjects = obj.data.subjects;
      let arr = [];
      for (let i = 0; i < subjects.length; i++) {
        arr.push(convertData(subjects[i]));
      }
      //data[key] = { "title": title, "movies": arr };
      //let json = '{'+key+':{ "title": title, "movies": arr }}';
      // json = JSON.parse(json);
      //data.setData(JSON.parse(json));
      if (cb){
        console.log(arr);
         cb(arr);
      }
    });
  });
}

// 将函数做为json对象导出，让其它用户使用
module.exports = {
  "getCity":getCity,
  "httpGet":get,
  "convertScore":convertScore,
  "convertTitle":convertTitle,
  "convertData": convertData,
  "parseData": parseData,
};