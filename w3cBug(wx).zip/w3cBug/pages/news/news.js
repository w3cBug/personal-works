// pages/news/news.js
// 引用外部数据文件
var newsData = require('../../data/news-data.js');
//console.log(newsData)

Page({
  
  "data": {
    "swiperItems": [
      {
        "src": "/images/news/car.jpg",
        "text": "世界上最有钱的国家之一 国民却买不起汽车",
        "newsId":3
      }, {
        "src": "/images/news/tang.jpg",
        "text": "唐嫣现身美得发光 黑衣红唇气质飙升",
        "newsId": 4
      }, {
        "src": "/images/news/love.jpg",
        "text": "爱情的本质 被佛陀一语道破！",
        "newsId": 5
      }
    ], "flag": true
  }, onLoad: function (options) {
    // this.data.newsData = newsData.newList;
    this.setData({ "newsData": newsData.newsList });
  }, onTap: function (event) {
    // 获取新闻id
    //console.log(event.currentTarget.dataset);
    let id = event.currentTarget.dataset.newsid;
    wx.navigateTo({
      url: '/pages/news/news-detail/news-detail?id=' + id + '&page=1',
    })
  }, onSwiperTap:function(e){
    //console.log(e);
    /*
      currentTarget     当前执行方法(函数)的对象
      target            触发事件发生的对象
      点击image事件传播到swiper从而执行了方法
      image是taget
      currentTarget是swiper
      如果触摸事件绑定在image上这个时候currentTarget和target都是同一个对象
     */
    let id = e.target.dataset.newsid;
    wx.navigateTo({
      url: '/pages/news/news-detail/news-detail?id=' + id
    })
  }, onPullDownRefresh: function () {
    wx.showNavigationBarLoading() //在标题栏中显示加载

    //模拟加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },

})

