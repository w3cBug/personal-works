// pages/news/news-detail/news-detail.js
let newsData = require('../../../data/news-data.js');
// 获取根目录的app.js文件里的代码 
let app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    "collected":false,
    "isPlaying":true,
    "isBackStop":false
  },

  /**
   * 生命周期函数--监听页面加载
   * @params(JSON) options    保存请求页面传递过来的参数
   */
  onLoad: function (options) {
    //console.log(app.globalData)
    //console.log(options);
    let id = options.id;
    let data = newsData.newsList;
    let music = null;
    for (let i=0;i<data.length;i++){
      if (data[i].newsId == id){
        this.setData({'news':data[i]});
        music = data[i].music;
        break;
      }
    }

    this.setData({ 'id': id })
    // 从缓存中获取collected数据
    // {id:true, id:false}
    let collections = wx.getStorageSync("collections");
    // 判断是否有collected对象，如果没有表示页面也没有打开过
    if (!collections){
      // 初始化collections
      wx.setStorageSync("collections", { id: false });
    }else{
      // 如果有colleected查找是否有打开过当前页，如果有获取选择状态
      if (collections[id]) {
        this.setData({ "collected": collections[id] });
      }
    } 

    this.setData({"isPlaying":app.globalData.isPlayingMusic});
    if (app.globalData.isPlayingMusic){
      if(music){
        wx.playBackgroundAudio({
          dataUrl: music.url,
          title: music.title,
          coverImgUrl: music.coverImg
        });
        // 调播放进度
        wx.seekBackgroundAudio({
          position: app.globalData.currentPosition
        })
      }
    }
    this.setMusicMonitor();
  }, onCollectedTap:function(){
    // this.data 保存的数据没有保存到data属性里
    //this.data.collected = !this.data.collected;
    //console.log(this.data.collected)
    let collected = !this.data.collected;
    
    
    // 保存到当前页面中，页面关闭后数据会丢失
    this.setData({"collected":collected});
    // 保存到缓存中，关闭页面后还可以获取到
    // 获取colledted对象
    let collections = wx.getStorageSync("collections");
    //wx.setStorageSync("collected", collected)
    collections[this.data.id] = collected;
    wx.setStorageSync("collections", collections);
    // showToast       一般用于用户提示
    wx.showToast({
      title: collected?'收藏成功':'取消收藏',
      duration: 1000,
      mask:true,
      icon:'loading'
    });

    // showModal       一般用于用户确认
   /* let collected = this.data.collected;
    let that = this;
    wx.showModal({
      title: '收藏',
      content: collected ? '取消收藏该文章' :'收藏该文章',
      success:function(e){
        if (e.confirm){   // 确认需要修改
          collected = !collected;
          that.setData({ 'collected': collected});
          let collections = wx.getStorageSync('collections');
          collections[that.data.id] = collected;
          wx.setStorageSync('collections', collections);
        }
      }
    });*/
  },onShareTap:function(){
    let itemList = ['分享到微信好友', '分享到朋友圈', '分享到QQ', '分享到微博'];
    // json使用{}时key不能使用变量，如果使用变量会变量当做是key
    // 如果需要使用变量的内容作为key，只能使用[]的方式
    wx.showActionSheet({
      itemList: itemList,
      success:function(e){
        //console.log(e);
        let index = e.tapIndex;// 获取点击按钮索引值
        wx.showModal({
          title: itemList[index],
          content: '请点击右上角菜单的“转发”按钮进行分享',
          showCancel: false
        })
      }
    })
  }, onMusicTap:function(){
    let isPlaying = this.data.isPlaying;
    this.setData({"isPlaying":!isPlaying});
    app.globalData.isPlayingMusic = !isPlaying;
    if (isPlaying){ // 如果正在播放暂停音乐
      wx.pauseBackgroundAudio();    // 暂停播放
      //wx.stopBackgroundAudio();     // 停止播放
    }else{ // 如果结束了播放需要开始播放
      this.playMusic();
    }
  }, setMusicMonitor:function(){
    let that = this;
    // 对音乐事件进行监听
    wx.onBackgroundAudioPlay(function () {
      that.setData({ "isPlaying": true });
      app.globalData.isPlayingMusic = true;
    })
    wx.onBackgroundAudioPause(function(){
      // 判断是否为返回上一页的暂停，如果不是状态不改变
      if (!that.data.isBackStop){
        //that.setData({"isPlaying":false});
        app.globalData.isPlayingMusic = false;
      }
      // 保存这次的播放进度
      wx.getBackgroundAudioPlayerState({
        "success": function (e) {
          app.globalData.currentPosition = e.currentPosition;
        }
      });
    });
    wx.onBackgroundAudioStop(function () {
      //that.playMusic();
    });
  },playMusic:function(){
    let music = this.data.news.music;
    wx.playBackgroundAudio({
      dataUrl: music.url,
      title: music.title,
      coverImgUrl: music.coverImg
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log('newsDetail.js调用了onUnload')
    //this.data.isBackStop = true;
    this.setData({"isBackStop":true});
    wx.pauseBackgroundAudio();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})