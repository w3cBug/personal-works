Page({

  /**
   * 页面的初始数据
   */
  data: {
    //"userImage":"/images/avatar/5.png",
    //"username":"小彬"
  },
  onTap: function(){
    // 只能是一般页面的调换，不能进入TabBar页面(进入后TabBar不显示)
    // wx.navigateTo({
    //   url: '/pages/news/news',
    // });
    wx.switchTab({
      url: '/pages/news/news',
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    
    // this.data.userImage = 'hahaha';
    // console.log(this.data.userImage);
    
    //获取用户微信信息
    let that = this;
    wx.getUserInfo({
      "success":function(res){
        let nickname = res.userInfo.nickName;
        let avatarurl = res.userInfo.avatarUrl;
        // 把数据添加到this对象中
        that.setData({
          "nickName":nickname,
          "avatarUrl":avatarurl
        });
      },
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 只会执行一次，第一次打开程序时会执行
    console.log('onready');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 第一次打开或者重新打开页面时会触发
    console.log('onshow');
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    // 接叫手机或切换到其它应用时会触发这个事件
    console.log('onhide');
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    // 关闭程序(该页面)时会触发
    console.log('onunload');
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})