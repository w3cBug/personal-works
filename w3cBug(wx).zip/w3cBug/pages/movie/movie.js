// pages/movie/movie.js

// 引用util工具
let util = require('../../util/util.js');
var movies = [{
    coverageUrl: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2503997609.webp",
    movieTitle: "寻梦环游记",
    stars: [true, true, true, true, false],
    starScore: "9.2",
    id: "20495023",
  }, {
    coverageUrl: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2504455660.webp",
    movieTitle: "烟花",
    stars: [true, true, true, false, false],
    starScore: "5.3",
    id: "26930504"
  }, {
    coverageUrl: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2504027804.webp",
    movieTitle: "正义联盟",
    stars: [true, true, true, true, false],
    starScore: "6.7",
    id: "2158490"
  }];

Page({

  /**
   * 页面的初始数据
   */
  data: {
    baseUrl:'https://api.douban.com/v2/movie/',
    "inStore": { "title": "正在热映", "movies": movies },
    "comingSoon": { "title": "即将上映", "movies": movies },
    "top250": { "title": "top250", "movies": movies },
    showGroupContainer: true,
    showSearchContainer: false,
    textValue:'',
    start:0,
    count:12
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 显示数据正在加载中的状态
    // wx.showNavigationBarLoading();
    let that = this;
    // 工具方法的调用
    // util.parseData(
    //   this.data.baseUrl + 'in_theaters?count=3', 
    //   function(arr){
    //     that.setData({"inStore":{ "title": "正在热映","movies":arr}});
    // }); 
    // util.parseData(
    //   this.data.baseUrl + 'coming_soon?count=3',
    //   function (arr) {
    //     that.setData({ "comingSoon": { "title": "即将上映", "movies": arr } });
    //   }); 
    // util.parseData(
    //   this.data.baseUrl + 'top250?count=3',
    //   function (arr) {
    //     that.setData({ "top250": { "title": "top250", "movies": arr } });
    //   }); 
     

    // 先获取地理位置
    /*wx.getLocation({
      success: function (res) {
        let latitude = res.latitude;
        let longitude = res.longitude;

        // 根据地理位置获取所在城市
        wx.request({
          url: 'https://api.map.baidu.com/geocoder/v2/?ak=2IBKO6GVxbYZvaR2mf0GWgZE&output=json&pois=0"&location=' + latitude + ',' + longitude,
          success: function (obj) {
            let city = obj.data.result.addressComponent.city;
            city = city.replace('市', '');

            // 向服务器发出请求获取数据
            let inTheaters = '1https://api.douban.com/v2/movie/in_theaters?count=3&city='+city;
            wx.request({
              url: inTheaters,
              method: 'get',
              dataType: 'json',
              header: {
                'Content-Type': 'json'
              },
              success: function (obj) {
                let subjects = obj.data.subjects;
                let arr = [];
                for (let i = 0; i < subjects.length; i++) {
                  let t = subjects[i];
                  let title = t.title;
                  let imageUrl = t.images.small;
                  let score = t.rating.average;
                  // 修改标题的长度，如果超过6个字截取前6个添加上省略号
                  if (title.length > 5) {
                    title = title.substring(0, 5) + "…";
                  }

                  let stars = [];
                  for (let j = 0; j < 5; j++) {
                    stars.push(Math.round(score / 2) > j);
                  }

                  arr.push({
                    coverageUrl: imageUrl,
                    movieTitle: title,
                    stars: stars,
                    starScore: '' + score
                  });
                }
                console.log(arr);
                that.setData({ "testData": { "title": "正在热映", "movies": arr } });
              }, fail: function (err) {
                console.log(err);
              }
            })
          }
        })
      },
    })*/
    // 模拟加载数据完成后修改状态
    // setTimeout(function(){
    //   // 隐藏进度加载控件
    //   wx.hideNavigationBarLoading();
    // }, 5000);
  },
  openDetails:function(e){
    // currentTarget      当前执行方法的对象
    // target             触发执行方法的对象
    // console.log(e);
    let id = e.currentTarget.dataset.movieId;
    // console.log(id); // 如果没有绑定，结果是undefined
    if(!id){
      return;
    }
    wx.navigateTo({
      url: '/pages/movie/movie-details/movie-details?id='+id,
    });
    // let url = this.data.baseUrl + '/subject/' + id;
    // wx.request({
    //   url: url,
    //   dataType: 'json',
    //   header:{'Content-Type':'json'},
    //   success:function(data){
    //     console.log(data)
    //   }
    // })
  }, onBindSerach:function(e){
    this.onSearch(e.detail.value);
  }, onCancleSearch:function(){
    this.setData({
      showSearchContainer: false,
      showGroupContainer: true,
      "searchResult":[],
      textValue: ''
    });
    console.log(this.data)
  }, onScrollToLower:function(){
    //加载更多的数据
    if (this.data.isLoading){
      return;
    }
    //console.log('到底部了')
    this.setData({
      start:this.data.start+this.data.count,
      isLoading:true
    });
    //console.log(this.data.textValue);
    this.onSearch(this.data.textValue);
  }, onSearch(searchText){
    // 搜索数据
    wx.showNavigationBarLoading();
    // console.log(e)
    let that = this;

    if (searchText.length < 1) {
      return;
    }
    let url = this.data.baseUrl + 'search?q=' + searchText + '&start=' + this.data.start + '&count=' + this.data.count;
    //console.log(url);
    util.httpGet(url, function (res) {
      console.log(res)
      let data = res.data.subjects
      //console.log(data);
      //let ary = []; // 保存查询到的电影数据
      let ary = that.data.searchResult ? that.data.searchResult : [];
      for (let i = 0; i < data.length; i++) {
        ary.push(util.convertData(data[i]));
      }
      //console.log(ary)
      that.setData({
        "searchResult": ary,
        showSearchContainer: true,
        showGroupContainer: false,
        isLoading:false,
        textValue: searchText
      });
      // that.data.showSearchContainer = true;
      // that.data.showGroupContainer = false;
      wx.hideNavigationBarLoading();
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
   
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})